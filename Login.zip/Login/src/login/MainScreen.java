/**
	* @Bantilan @Jarabelo @Rosales	 ITCC11 B
	* November 18 2020
	* FINAL PROJECT
	*/

package login;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import static java.lang.Thread.sleep;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Vector;
import javax.swing.JOptionPane;
import sun.audio.AudioPlayer;
import sun.audio.AudioStream;
import java.util.GregorianCalendar;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.Timer;

/**
 *
 * @author Geral
 */
public class MainScreen extends javax.swing.JFrame {

    //for Activities
    Vector Activity1, Activity2, Activity3, Activity4, Activity5, Activity6, Activity7, Activity8, Activity9, Activity10;

    /**
     * Creates new form MainScreen
     */



    
    private Timer timer1, timer2, timer3, timer4, timer5, timer6, timer7, timer8, timer9, timer10;
    
    private ActionListener al1,a12,a13,a14,a15,a16,a17,a18,a19,al10;
    
    public MainScreen() {

        // for clock

        timer1();
        //currentTime();
        initComponents();
       
    //Progress 1    
    al1 = new ActionListener(){
        public void actionPerformed(ActionEvent ae){
            if(jProgressBar1.getValue()< 100)
            {jProgressBar1.setValue(jProgressBar1.getValue()+5);}
            else{timer1.stop();
                System.out.print("Done!!");
            }
        }
    };
    
        timer1 = new Timer(200,al1);
    //Progress 2
     a12 = new ActionListener(){
        public void actionPerformed(ActionEvent ae){
            if(jProgressBar2.getValue()< 100)
            {jProgressBar2.setValue(jProgressBar2.getValue()+5);}
            else{timer2.stop();
                System.out.print("Done!!");
            }
        }
    };
         timer2 = new Timer(200,a12);
         
          a13 = new ActionListener(){
        public void actionPerformed(ActionEvent ae){
            if(jProgressBar3.getValue()< 100)
            {jProgressBar3.setValue(jProgressBar3.getValue()+5);}
            else{timer3.stop();
                System.out.print("Done!!");
            }
        }
    };
         timer3 = new Timer(200,a13);
         
        a14 = new ActionListener(){
        public void actionPerformed(ActionEvent ae){
            if(jProgressBar4.getValue()< 100)
            {jProgressBar4.setValue(jProgressBar4.getValue()+5);}
            else{timer4.stop();
                System.out.print("Done!!");
            }
        }
    };
         timer4 = new Timer(200,a14); 
         
         a15 = new ActionListener(){
        public void actionPerformed(ActionEvent ae){
            if(jProgressBar5.getValue()< 100)
            {jProgressBar5.setValue(jProgressBar5.getValue()+5);}
            else{timer5.stop();
                System.out.print("Done!!");
            }
        }
    };
         timer5 = new Timer(200,a15); 
         
         a16 = new ActionListener(){
        public void actionPerformed(ActionEvent ae){
            if(jProgressBar6.getValue()< 100)
            {jProgressBar6.setValue(jProgressBar6.getValue()+5);}
            else{timer6.stop();
                System.out.print("Done!!");
            }
        }
    };
         timer6 = new Timer(200,a16); 
         
         a17 = new ActionListener(){
        public void actionPerformed(ActionEvent ae){
            if(jProgressBar7.getValue()< 100)
            {jProgressBar7.setValue(jProgressBar7.getValue()+5);}
            else{timer7.stop();
                System.out.print("Done!!");
            }
        }
    };
         timer7 = new Timer(200,a17); 
         
         a18 = new ActionListener(){
        public void actionPerformed(ActionEvent ae){
            if(jProgressBar8.getValue()< 100)
            {jProgressBar8.setValue(jProgressBar8.getValue()+5);}
            else{timer8.stop();
                System.out.print("Done!!");
            }
        }
    };
         timer8 = new Timer(200,a18); 
         
         a19 = new ActionListener(){
        public void actionPerformed(ActionEvent ae){
            if(jProgressBar9.getValue()< 100)
            {jProgressBar9.setValue(jProgressBar9.getValue()+5);}
            else{timer9.stop();
                System.out.print("Done!!");
            }
        }
    };
         timer9 = new Timer(200,a19); 
         
         al10 = new ActionListener(){
        public void actionPerformed(ActionEvent ae){
            if(jProgressBar10.getValue()< 100)
            {jProgressBar10.setValue(jProgressBar10.getValue()+5);}
            else{timer10.stop();
                System.out.print("Done!!");
            }
        }
    };
         timer10 = new Timer(200,al10); 
         
        this.setLocationRelativeTo(null); //center frm in the screen
        this.setResizable(false);
    }
    
    
    
    
    
    // for alarm timer
    
    public void timer1 (){

         Timer timer;
         ActionListener actionlistener = new ActionListener(){
                    // PRINTING FOR VARIABLES
                     public void actionPerformed(ActionEvent e ){

                    Date date = new Date();
                    DateFormat timeFormat = new SimpleDateFormat("hh:mm:ss a");
                    SimpleDateFormat df = new SimpleDateFormat("MM:dd:yyyy");
                         String time = timeFormat.format(date);
                         jLabel9.setText(time);
                         jLabel10.setText(df.format(date));
                     }
                     };
                     timer = new Timer(1000, actionlistener);
                     timer.setInitialDelay(0);
                     timer.start();
    }

    public void  SetAlarm(){
         String t11, t22, t33, t44, t55, t66, t77, t88, t99, t100;
                t11=t1.getText();
                t22=t2.getText();
                t33=t3.getText();
                t44=t4.getText();
                t55=t5.getText();
                t66=t6.getText();
                t77=t7.getText();
                t88=t8.getText();
                t99=t9.getText();
                t100=t10.getText();
                
        
             Thread clock;
        clock = new Thread() {

            public void run() {

                for (;;) {

                    // PRINTING FOR VARIABLES
                    Date d = new Date();
                    SimpleDateFormat sdf = new SimpleDateFormat("hh:mm:ss a");
                    jLabel9.setText(sdf.format(d));


                    if (jLabel9.getText().equals(t11) ||  jLabel9.getText().equals(t22) ||  jLabel9.getText().equals(t33)
                            ||  jLabel9.getText().equals(t44) ||  jLabel9.getText().equals(t55) ||  jLabel9.getText().equals(t66) 
                            ||  jLabel9.getText().equals(t77) ||  jLabel9.getText().equals(t88) ||  jLabel9.getText().equals(t99)
                            ||  jLabel9.getText().equals(t100)){
                        jLabel7.setText("TIME FOR YOUR HOME WORK");

                         PlayAlarm();
                    }



                }
            }

        };
        clock.start();


    }public void PlayAlarm(){
                       InputStream in;      
                        try { 
                            in = new FileInputStream(new File("src\\wav\\alarm.wav"));
                            AudioStream aa = new AudioStream(in);
                            AudioPlayer.player.start(aa);

                        } catch (Exception e) {

                            JOptionPane.showMessageDialog(null, e);
                        }
    }


    {

        Activity1 = new Vector();
        Activity2 = new Vector();
        Activity3 = new Vector();
        Activity4 = new Vector();
        Activity5 = new Vector();
        Activity6 = new Vector();
        Activity7 = new Vector();
        Activity8 = new Vector();
        Activity9 = new Vector();
        Activity10 = new Vector();

    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        kGradientPanel1 = new keeptoo.KGradientPanel();
        jLabel3 = new javax.swing.JLabel();
        kGradientPanel2 = new keeptoo.KGradientPanel();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        AddButton2 = new javax.swing.JButton();
        RemoveButton2 = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        AddButton3 = new javax.swing.JButton();
        RemoveButton3 = new javax.swing.JButton();
        jPanel4 = new javax.swing.JPanel();
        AddButton4 = new javax.swing.JButton();
        RemoveButton4 = new javax.swing.JButton();
        jPanel5 = new javax.swing.JPanel();
        AddButton5 = new javax.swing.JButton();
        RemoveButton5 = new javax.swing.JButton();
        jPanel6 = new javax.swing.JPanel();
        AddButton6 = new javax.swing.JButton();
        RemoveButton6 = new javax.swing.JButton();
        jPanel7 = new javax.swing.JPanel();
        AddButton7 = new javax.swing.JButton();
        RemoveButton7 = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        jPanel8 = new javax.swing.JPanel();
        AddButton8 = new javax.swing.JButton();
        RemoveButton8 = new javax.swing.JButton();
        jPanel9 = new javax.swing.JPanel();
        AddButton9 = new javax.swing.JButton();
        RemoveButton9 = new javax.swing.JButton();
        jPanel10 = new javax.swing.JPanel();
        AddButton10 = new javax.swing.JButton();
        RemoveButton10 = new javax.swing.JButton();
        jPanel11 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        ActivityList2 = new javax.swing.JList<>();
        jScrollPane3 = new javax.swing.JScrollPane();
        ActivityList3 = new javax.swing.JList<>();
        jScrollPane4 = new javax.swing.JScrollPane();
        ActivityList4 = new javax.swing.JList<>();
        jScrollPane5 = new javax.swing.JScrollPane();
        ActivityList5 = new javax.swing.JList<>();
        jScrollPane6 = new javax.swing.JScrollPane();
        ActivityList6 = new javax.swing.JList<>();
        jScrollPane7 = new javax.swing.JScrollPane();
        ActivityList7 = new javax.swing.JList<>();
        jScrollPane8 = new javax.swing.JScrollPane();
        ActivityList8 = new javax.swing.JList<>();
        jScrollPane9 = new javax.swing.JScrollPane();
        ActivityList9 = new javax.swing.JList<>();
        jScrollPane10 = new javax.swing.JScrollPane();
        ActivityList10 = new javax.swing.JList<>();
        jScrollPane1 = new javax.swing.JScrollPane();
        ActivityList1 = new javax.swing.JList<>();
        jComboBox1 = new javax.swing.JComboBox<>();
        jPanel1 = new javax.swing.JPanel();
        AddButton1 = new javax.swing.JButton();
        RemoveButton1 = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        kGradientPanel4 = new keeptoo.KGradientPanel();
        jLabel5 = new javax.swing.JLabel();
        t3 = new javax.swing.JTextField();
        t4 = new javax.swing.JTextField();
        t6 = new javax.swing.JTextField();
        t2 = new javax.swing.JTextField();
        t7 = new javax.swing.JTextField();
        t1 = new javax.swing.JTextField();
        t8 = new javax.swing.JTextField();
        t10 = new javax.swing.JTextField();
        t5 = new javax.swing.JTextField();
        t9 = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        jProgressBar1 = new javax.swing.JProgressBar();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jButton2 = new javax.swing.JButton();
        jProgressBar2 = new javax.swing.JProgressBar();
        jProgressBar3 = new javax.swing.JProgressBar();
        jProgressBar4 = new javax.swing.JProgressBar();
        jProgressBar5 = new javax.swing.JProgressBar();
        jProgressBar6 = new javax.swing.JProgressBar();
        jProgressBar7 = new javax.swing.JProgressBar();
        jProgressBar8 = new javax.swing.JProgressBar();
        jProgressBar9 = new javax.swing.JProgressBar();
        jProgressBar10 = new javax.swing.JProgressBar();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);

        kGradientPanel1.setkEndColor(new java.awt.Color(0, 51, 153));
        kGradientPanel1.setkStartColor(new java.awt.Color(153, 153, 153));

        jLabel3.setFont(new java.awt.Font("Century Gothic", 1, 24)); // NOI18N
        jLabel3.setText("Welcome to Acti-TRACKER");

        kGradientPanel2.setkEndColor(new java.awt.Color(0, 51, 153));
        kGradientPanel2.setkStartColor(new java.awt.Color(153, 153, 153));

        jButton3.setText("X");
        jButton3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton3MouseClicked(evt);
            }
        });

        jButton4.setText("-");
        jButton4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton4MouseClicked(evt);
            }
        });
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        jLabel6.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel6.setText("MAIN SCREEN");

        javax.swing.GroupLayout kGradientPanel2Layout = new javax.swing.GroupLayout(kGradientPanel2);
        kGradientPanel2.setLayout(kGradientPanel2Layout);
        kGradientPanel2Layout.setHorizontalGroup(
            kGradientPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, kGradientPanel2Layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(jLabel6)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 590, Short.MAX_VALUE)
                .addComponent(jButton4)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButton3)
                .addGap(6, 6, 6))
        );
        kGradientPanel2Layout.setVerticalGroup(
            kGradientPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(kGradientPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(kGradientPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton3)
                    .addComponent(jButton4)
                    .addComponent(jLabel6))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel1.setText("Your ACTIVITIES");

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel2.setText("ADD / REMOVE ");

        jPanel2.setBackground(new java.awt.Color(51, 51, 51));
        jPanel2.setForeground(new java.awt.Color(102, 102, 255));
        jPanel2.setLayout(new java.awt.GridLayout(1, 2, 5, 5));

        AddButton2.setText("ADD");
        AddButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AddButton2ActionPerformed(evt);
            }
        });
        jPanel2.add(AddButton2);

        RemoveButton2.setText("REMOVE");
        RemoveButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RemoveButton2ActionPerformed(evt);
            }
        });
        jPanel2.add(RemoveButton2);

        jPanel3.setBackground(new java.awt.Color(51, 51, 51));
        jPanel3.setForeground(new java.awt.Color(102, 102, 255));
        jPanel3.setLayout(new java.awt.GridLayout(1, 2, 5, 5));

        AddButton3.setText("ADD");
        AddButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AddButton3ActionPerformed(evt);
            }
        });
        jPanel3.add(AddButton3);

        RemoveButton3.setText("REMOVE");
        RemoveButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RemoveButton3ActionPerformed(evt);
            }
        });
        jPanel3.add(RemoveButton3);

        jPanel4.setBackground(new java.awt.Color(51, 51, 51));
        jPanel4.setForeground(new java.awt.Color(102, 102, 255));
        jPanel4.setLayout(new java.awt.GridLayout(1, 2, 5, 5));

        AddButton4.setText("ADD");
        AddButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AddButton4ActionPerformed(evt);
            }
        });
        jPanel4.add(AddButton4);

        RemoveButton4.setText("REMOVE");
        RemoveButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RemoveButton4ActionPerformed(evt);
            }
        });
        jPanel4.add(RemoveButton4);

        jPanel5.setBackground(new java.awt.Color(51, 51, 51));
        jPanel5.setForeground(new java.awt.Color(102, 102, 255));
        jPanel5.setLayout(new java.awt.GridLayout(1, 2, 5, 5));

        AddButton5.setText("ADD");
        AddButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AddButton5ActionPerformed(evt);
            }
        });
        jPanel5.add(AddButton5);

        RemoveButton5.setText("REMOVE");
        RemoveButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RemoveButton5ActionPerformed(evt);
            }
        });
        jPanel5.add(RemoveButton5);

        jPanel6.setBackground(new java.awt.Color(51, 51, 51));
        jPanel6.setForeground(new java.awt.Color(102, 102, 255));
        jPanel6.setLayout(new java.awt.GridLayout(1, 2, 5, 5));

        AddButton6.setText("ADD");
        AddButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AddButton6ActionPerformed(evt);
            }
        });
        jPanel6.add(AddButton6);

        RemoveButton6.setText("REMOVE");
        RemoveButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RemoveButton6ActionPerformed(evt);
            }
        });
        jPanel6.add(RemoveButton6);

        jPanel7.setBackground(new java.awt.Color(51, 51, 51));
        jPanel7.setForeground(new java.awt.Color(102, 102, 255));
        jPanel7.setLayout(new java.awt.GridLayout(1, 2, 5, 5));

        AddButton7.setText("ADD");
        AddButton7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AddButton7ActionPerformed(evt);
            }
        });
        jPanel7.add(AddButton7);

        RemoveButton7.setText("REMOVE");
        RemoveButton7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RemoveButton7ActionPerformed(evt);
            }
        });
        jPanel7.add(RemoveButton7);

        jButton1.setText("Set Alarm");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jPanel8.setBackground(new java.awt.Color(51, 51, 51));
        jPanel8.setForeground(new java.awt.Color(102, 102, 255));
        jPanel8.setLayout(new java.awt.GridLayout(1, 2, 5, 5));

        AddButton8.setText("ADD");
        AddButton8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AddButton8ActionPerformed(evt);
            }
        });
        jPanel8.add(AddButton8);

        RemoveButton8.setText("REMOVE");
        RemoveButton8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RemoveButton8ActionPerformed(evt);
            }
        });
        jPanel8.add(RemoveButton8);

        jPanel9.setBackground(new java.awt.Color(51, 51, 51));
        jPanel9.setForeground(new java.awt.Color(102, 102, 255));
        jPanel9.setLayout(new java.awt.GridLayout(1, 2, 5, 5));

        AddButton9.setText("ADD");
        AddButton9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AddButton9ActionPerformed(evt);
            }
        });
        jPanel9.add(AddButton9);

        RemoveButton9.setText("REMOVE");
        RemoveButton9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RemoveButton9ActionPerformed(evt);
            }
        });
        jPanel9.add(RemoveButton9);

        jPanel10.setBackground(new java.awt.Color(51, 51, 51));
        jPanel10.setForeground(new java.awt.Color(102, 102, 255));
        jPanel10.setLayout(new java.awt.GridLayout(1, 2, 5, 5));

        AddButton10.setText("ADD");
        AddButton10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AddButton10ActionPerformed(evt);
            }
        });
        jPanel10.add(AddButton10);

        RemoveButton10.setText("REMOVE");
        RemoveButton10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RemoveButton10ActionPerformed(evt);
            }
        });
        jPanel10.add(RemoveButton10);

        jPanel11.setBackground(new java.awt.Color(28, 38, 84));

        ActivityList2.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jScrollPane2.setViewportView(ActivityList2);

        ActivityList3.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jScrollPane3.setViewportView(ActivityList3);

        ActivityList4.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jScrollPane4.setViewportView(ActivityList4);

        ActivityList5.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jScrollPane5.setViewportView(ActivityList5);

        ActivityList6.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jScrollPane6.setViewportView(ActivityList6);

        ActivityList7.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jScrollPane7.setViewportView(ActivityList7);

        ActivityList8.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jScrollPane8.setViewportView(ActivityList8);

        ActivityList9.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jScrollPane9.setViewportView(ActivityList9);

        ActivityList10.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jScrollPane10.setViewportView(ActivityList10);

        ActivityList1.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jScrollPane1.setViewportView(ActivityList1);

        javax.swing.GroupLayout jPanel11Layout = new javax.swing.GroupLayout(jPanel11);
        jPanel11.setLayout(jPanel11Layout);
        jPanel11Layout.setHorizontalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel11Layout.createSequentialGroup()
                .addContainerGap(27, Short.MAX_VALUE)
                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jScrollPane1)
                    .addComponent(jScrollPane2)
                    .addComponent(jScrollPane3)
                    .addComponent(jScrollPane4)
                    .addComponent(jScrollPane5)
                    .addComponent(jScrollPane6)
                    .addComponent(jScrollPane7)
                    .addComponent(jScrollPane8)
                    .addComponent(jScrollPane9)
                    .addComponent(jScrollPane10))
                .addGap(26, 26, 26))
        );
        jPanel11Layout.setVerticalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel11Layout.createSequentialGroup()
                .addContainerGap(37, Short.MAX_VALUE)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane7, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane8, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane9, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane10, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(35, 35, 35))
        );

        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Profile", "Logout" }));
        jComboBox1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox1ActionPerformed(evt);
            }
        });

        jPanel1.setBackground(new java.awt.Color(51, 51, 51));
        jPanel1.setForeground(new java.awt.Color(102, 102, 255));
        jPanel1.setLayout(new java.awt.GridLayout(1, 2, 5, 5));

        AddButton1.setText("ADD");
        AddButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AddButton1ActionPerformed(evt);
            }
        });
        jPanel1.add(AddButton1);

        RemoveButton1.setText("REMOVE");
        RemoveButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RemoveButton1ActionPerformed(evt);
            }
        });
        jPanel1.add(RemoveButton1);

        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/profile_icon-removebg-preview-.png"))); // NOI18N

        kGradientPanel4.setkEndColor(new java.awt.Color(153, 153, 153));
        kGradientPanel4.setkStartColor(new java.awt.Color(0, 51, 153));

        javax.swing.GroupLayout kGradientPanel4Layout = new javax.swing.GroupLayout(kGradientPanel4);
        kGradientPanel4.setLayout(kGradientPanel4Layout);
        kGradientPanel4Layout.setHorizontalGroup(
            kGradientPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 440, Short.MAX_VALUE)
        );
        kGradientPanel4Layout.setVerticalGroup(
            kGradientPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 9, Short.MAX_VALUE)
        );

        jLabel5.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel5.setText("ACTIVITES");

        t2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t2ActionPerformed(evt);
            }
        });

        t1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t1ActionPerformed(evt);
            }
        });

        jLabel7.setBackground(new java.awt.Color(0, 0, 0));
        jLabel7.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(204, 0, 51));

        jLabel8.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel8.setText("PROGRESS ");

        jLabel9.setFont(new java.awt.Font("Verdana", 1, 24)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(0, 255, 255));

        jLabel10.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N

        jButton2.setText("HH:MM:SS");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout kGradientPanel1Layout = new javax.swing.GroupLayout(kGradientPanel1);
        kGradientPanel1.setLayout(kGradientPanel1Layout);
        kGradientPanel1Layout.setHorizontalGroup(
            kGradientPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(kGradientPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(kGradientPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(kGradientPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 89, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(kGradientPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(kGradientPanel1Layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(kGradientPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel1)
                                    .addGroup(kGradientPanel1Layout.createSequentialGroup()
                                        .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(147, 147, 147)
                                        .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 182, javax.swing.GroupLayout.PREFERRED_SIZE))))
                            .addGroup(kGradientPanel1Layout.createSequentialGroup()
                                .addGap(162, 162, 162)
                                .addComponent(jLabel3))))
                    .addGroup(kGradientPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 270, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(kGradientPanel1Layout.createSequentialGroup()
                            .addComponent(jPanel11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addGroup(kGradientPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jPanel8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jPanel9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jPanel10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGroup(kGradientPanel1Layout.createSequentialGroup()
                                    .addGap(28, 28, 28)
                                    .addGroup(kGradientPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addGroup(kGradientPanel1Layout.createSequentialGroup()
                                            .addGap(11, 11, 11)
                                            .addComponent(jLabel5))
                                        .addComponent(jLabel2, javax.swing.GroupLayout.Alignment.TRAILING)))
                                .addComponent(jLabel10, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 137, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addGroup(kGradientPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(kGradientPanel1Layout.createSequentialGroup()
                                    .addComponent(t2, javax.swing.GroupLayout.PREFERRED_SIZE, 92, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGap(18, 18, 18)
                                    .addComponent(jProgressBar2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(kGradientPanel1Layout.createSequentialGroup()
                                    .addGroup(kGradientPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addComponent(jButton2, javax.swing.GroupLayout.DEFAULT_SIZE, 92, Short.MAX_VALUE)
                                        .addComponent(jButton1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                    .addGap(48, 48, 48)
                                    .addComponent(jLabel8))
                                .addGroup(kGradientPanel1Layout.createSequentialGroup()
                                    .addComponent(t6, javax.swing.GroupLayout.PREFERRED_SIZE, 92, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGap(18, 18, 18)
                                    .addComponent(jProgressBar6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(kGradientPanel1Layout.createSequentialGroup()
                                    .addComponent(t9, javax.swing.GroupLayout.PREFERRED_SIZE, 92, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGap(18, 18, 18)
                                    .addComponent(jProgressBar9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(kGradientPanel1Layout.createSequentialGroup()
                                    .addComponent(t3, javax.swing.GroupLayout.PREFERRED_SIZE, 92, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGap(18, 18, 18)
                                    .addComponent(jProgressBar3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(kGradientPanel1Layout.createSequentialGroup()
                                    .addComponent(t4, javax.swing.GroupLayout.PREFERRED_SIZE, 92, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGap(18, 18, 18)
                                    .addComponent(jProgressBar4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(kGradientPanel1Layout.createSequentialGroup()
                                    .addComponent(t5, javax.swing.GroupLayout.PREFERRED_SIZE, 92, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGap(18, 18, 18)
                                    .addComponent(jProgressBar5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(kGradientPanel1Layout.createSequentialGroup()
                                    .addComponent(t1, javax.swing.GroupLayout.PREFERRED_SIZE, 92, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGap(18, 18, 18)
                                    .addComponent(jProgressBar1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(kGradientPanel1Layout.createSequentialGroup()
                                    .addComponent(t7, javax.swing.GroupLayout.PREFERRED_SIZE, 92, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGap(18, 18, 18)
                                    .addComponent(jProgressBar7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(kGradientPanel1Layout.createSequentialGroup()
                                    .addComponent(t8, javax.swing.GroupLayout.PREFERRED_SIZE, 92, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGap(18, 18, 18)
                                    .addComponent(jProgressBar8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(kGradientPanel1Layout.createSequentialGroup()
                                    .addComponent(t10, javax.swing.GroupLayout.PREFERRED_SIZE, 92, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGap(18, 18, 18)
                                    .addComponent(jProgressBar10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(kGradientPanel1Layout.createSequentialGroup()
                .addGroup(kGradientPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(kGradientPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(kGradientPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 3, Short.MAX_VALUE))
        );
        kGradientPanel1Layout.setVerticalGroup(
            kGradientPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(kGradientPanel1Layout.createSequentialGroup()
                .addComponent(kGradientPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(kGradientPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, kGradientPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 72, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, kGradientPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel3)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 49, Short.MAX_VALUE)
                .addGroup(kGradientPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(kGradientPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jPanel11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(10, 10, 10)
                        .addComponent(kGradientPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(kGradientPanel1Layout.createSequentialGroup()
                        .addGroup(kGradientPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(kGradientPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel2)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jLabel5)
                                .addGap(20, 20, 20))
                            .addGroup(kGradientPanel1Layout.createSequentialGroup()
                                .addGroup(kGradientPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jLabel8)
                                    .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jButton2)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)))
                        .addGroup(kGradientPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(kGradientPanel1Layout.createSequentialGroup()
                                .addGroup(kGradientPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(t3, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(kGradientPanel1Layout.createSequentialGroup()
                                        .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(18, 18, 18)
                                        .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(18, 18, 18)
                                        .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addGap(18, 18, 18)
                                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(jPanel8, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(kGradientPanel1Layout.createSequentialGroup()
                                .addGroup(kGradientPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(kGradientPanel1Layout.createSequentialGroup()
                                        .addGroup(kGradientPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                            .addGroup(kGradientPanel1Layout.createSequentialGroup()
                                                .addGroup(kGradientPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                                    .addGroup(kGradientPanel1Layout.createSequentialGroup()
                                                        .addGroup(kGradientPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                            .addComponent(t1, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                            .addComponent(jProgressBar1, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                        .addGap(18, 18, 18)
                                                        .addGroup(kGradientPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                            .addComponent(t2, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                            .addComponent(jProgressBar2, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                        .addGroup(kGradientPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                                            .addGroup(kGradientPanel1Layout.createSequentialGroup()
                                                                .addGap(71, 71, 71)
                                                                .addComponent(t4, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                            .addGroup(kGradientPanel1Layout.createSequentialGroup()
                                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                                .addComponent(jProgressBar3, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                                .addGap(18, 18, 18)
                                                                .addComponent(jProgressBar4, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                                        .addGap(18, 18, 18)
                                                        .addComponent(t5, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                    .addComponent(jProgressBar5, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                .addGap(18, 18, 18)
                                                .addComponent(t6, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addComponent(jProgressBar6, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGap(18, 18, 18)
                                        .addComponent(t7, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addComponent(jProgressBar7, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(18, 18, 18)
                                .addGroup(kGradientPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(t8, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jProgressBar8, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addGap(18, 18, 18)
                        .addGroup(kGradientPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jPanel9, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(t9, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jProgressBar9, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(15, 15, 15)
                        .addGroup(kGradientPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(t10, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jPanel10, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jProgressBar10, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(5, 5, 5))))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(kGradientPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(kGradientPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton3MouseClicked
        System.exit(0);
    }//GEN-LAST:event_jButton3MouseClicked

    private void jButton4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton4MouseClicked
        this.setState(Register.ICONIFIED);
    }//GEN-LAST:event_jButton4MouseClicked

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton4ActionPerformed

    private void AddButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AddButton1ActionPerformed
        String Act1 = JOptionPane.showInputDialog(this, "Enter Activity Name:");
        Activity1.add(Act1);
        ActivityList1.setListData(Activity1);
        jProgressBar1.setValue(0);

    }//GEN-LAST:event_AddButton1ActionPerformed

    private void RemoveButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RemoveButton1ActionPerformed
        

// get the selected Activity
        int index = ActivityList1.getSelectedIndex();
        

        // if there is no Activity Selected the index -1
        if (index == -1) {
            JOptionPane.showMessageDialog(this, "You did not select any Activity to remove",
                    "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            //remove the activity from the vector w/ the index

            Activity1.remove(index);

            // set the Activity vector as the List data of the namesList
            ActivityList1.setListData(Activity1);
            timer1.start();
        }
    }//GEN-LAST:event_RemoveButton1ActionPerformed

    private void AddButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AddButton3ActionPerformed
        
        String Act3 = JOptionPane.showInputDialog(this, "Enter Activity Name:");
        Activity3.add(Act3);
        ActivityList3.setListData(Activity3);
        jProgressBar3.setValue(0);
    }//GEN-LAST:event_AddButton3ActionPerformed

    private void RemoveButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RemoveButton3ActionPerformed
        // get the selected Activity
        
        int index = ActivityList3.getSelectedIndex();

        // if there is no Activity Selected the index -1
        if (index == -1) {
            JOptionPane.showMessageDialog(this, "You did not select any Activity to remove",
                    "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            //remove the activity from the vector w/ the index

            Activity3.remove(index);

            // set the Activity vector as the List data of the namesList
            ActivityList3.setListData(Activity3);
            timer3.start();
        }
    }//GEN-LAST:event_RemoveButton3ActionPerformed

    private void RemoveButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RemoveButton2ActionPerformed
        // get the selected Activity
        int index = ActivityList2.getSelectedIndex();

        // if there is no Activity Selected the index -1
        if (index == -1) {
            JOptionPane.showMessageDialog(this, "You did not select any Activity to remove",
                    "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            //remove the activity from the vector w/ the index

            Activity2.remove(index);

            // set the Activity vector as the List data of the namesList
            ActivityList2.setListData(Activity2);
            timer2.start();
        }
    }//GEN-LAST:event_RemoveButton2ActionPerformed

    private void AddButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AddButton2ActionPerformed

        String Act2 = JOptionPane.showInputDialog(this, "Enter Activity Name:");
        Activity2.add(Act2);
        ActivityList2.setListData(Activity2);
        jProgressBar2.setValue(0);

    }//GEN-LAST:event_AddButton2ActionPerformed

    private void AddButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AddButton4ActionPerformed
        String Act4 = JOptionPane.showInputDialog(this, "Enter Activity Name:");
        Activity4.add(Act4);
        ActivityList4.setListData(Activity4);
        jProgressBar4.setValue(0);
    }//GEN-LAST:event_AddButton4ActionPerformed

    private void RemoveButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RemoveButton4ActionPerformed
        // get the selected Activity
        int index = ActivityList4.getSelectedIndex();

        // if there is no Activity Selected the index -1
        if (index == -1) {
            JOptionPane.showMessageDialog(this, "You did not select any Activity to remove",
                    "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            //remove the activity from the vector w/ the index

            Activity4.remove(index);

            // set the Activity vector as the List data of the namesList
            ActivityList4.setListData(Activity4);
            timer4.start();
        }
    }//GEN-LAST:event_RemoveButton4ActionPerformed

    private void AddButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AddButton5ActionPerformed
        String Act5 = JOptionPane.showInputDialog(this, "Enter Activity Name:");
        Activity5.add(Act5);
        ActivityList5.setListData(Activity5);
        jProgressBar5.setValue(0);
    }//GEN-LAST:event_AddButton5ActionPerformed

    private void RemoveButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RemoveButton5ActionPerformed
        // get the selected Activity
        int index = ActivityList5.getSelectedIndex();

        // if there is no Activity Selected the index -1
        if (index == -1) {
            JOptionPane.showMessageDialog(this, "You did not select any Activity to remove",
                    "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            //remove the activity from the vector w/ the index

            Activity5.remove(index);

            // set the Activity vector as the List data of the namesList
            ActivityList5.setListData(Activity5);
            timer5.start();
        }
    }//GEN-LAST:event_RemoveButton5ActionPerformed

    private void AddButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AddButton6ActionPerformed
        String Act6 = JOptionPane.showInputDialog(this, "Enter Activity Name:");
        Activity6.add(Act6);
        ActivityList6.setListData(Activity6);
        jProgressBar6.setValue(0);
    }//GEN-LAST:event_AddButton6ActionPerformed

    private void RemoveButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RemoveButton6ActionPerformed
        // get the selected Activity
        int index = ActivityList6.getSelectedIndex();

        // if there is no Activity Selected the index -1
        if (index == -1) {
            JOptionPane.showMessageDialog(this, "You did not select any Activity to remove",
                    "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            //remove the activity from the vector w/ the index

            Activity6.remove(index);

            // set the Activity vector as the List data of the namesList
            ActivityList6.setListData(Activity6);
            timer6.start();
        }
    }//GEN-LAST:event_RemoveButton6ActionPerformed

    private void AddButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AddButton7ActionPerformed
        String Act7 = JOptionPane.showInputDialog(this, "Enter Activity Name:");
        Activity7.add(Act7);
        ActivityList7.setListData(Activity7);
        jProgressBar7.setValue(0);
    }//GEN-LAST:event_AddButton7ActionPerformed

    private void RemoveButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RemoveButton7ActionPerformed
        // get the selected Activity
        int index = ActivityList7.getSelectedIndex();

        // if there is no Activity Selected the index -1
        if (index == -1) {
            JOptionPane.showMessageDialog(this, "You did not select any Activity to remove",
                    "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            //remove the activity from the vector w/ the index

            Activity7.remove(index);

            // set the Activity vector as the List data of the namesList
            ActivityList7.setListData(Activity7);
            timer7.start();
        }
    }//GEN-LAST:event_RemoveButton7ActionPerformed

    private void AddButton8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AddButton8ActionPerformed
        String Act8 = JOptionPane.showInputDialog(this, "Enter Activity Name:");
        Activity8.add(Act8);
        ActivityList8.setListData(Activity8);
        jProgressBar8.setValue(0);
    }//GEN-LAST:event_AddButton8ActionPerformed

    private void RemoveButton8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RemoveButton8ActionPerformed
        // get the selected Activity
        int index = ActivityList8.getSelectedIndex();

        // if there is no Activity Selected the index -1
        if (index == -1) {
            JOptionPane.showMessageDialog(this, "You did not select any Activity to remove",
                    "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            //remove the activity from the vector w/ the index

            Activity8.remove(index);

            // set the Activity vector as the List data of the namesList
            ActivityList8.setListData(Activity8);
            timer8.start();
        }
    }//GEN-LAST:event_RemoveButton8ActionPerformed

    private void AddButton9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AddButton9ActionPerformed
        String Act9 = JOptionPane.showInputDialog(this, "Enter Activity Name:");
        Activity9.add(Act9);
        ActivityList9.setListData(Activity9);
        jProgressBar9.setValue(0);
    }//GEN-LAST:event_AddButton9ActionPerformed

    private void RemoveButton9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RemoveButton9ActionPerformed
        // get the selected Activity
        int index = ActivityList9.getSelectedIndex();

        // if there is no Activity Selected the index -1
        if (index == -1) {
            JOptionPane.showMessageDialog(this, "You did not select any Activity to remove",
                    "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            //remove the activity from the vector w/ the index

            Activity9.remove(index);

            // set the Activity vector as the List data of the namesList
            ActivityList9.setListData(Activity9);
            timer9.start();
        }
    }//GEN-LAST:event_RemoveButton9ActionPerformed

    private void AddButton10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AddButton10ActionPerformed
        String Act10 = JOptionPane.showInputDialog(this, "Enter Activity Name:");
        Activity10.add(Act10);
        ActivityList10.setListData(Activity10);
        jProgressBar10.setValue(0);
    }//GEN-LAST:event_AddButton10ActionPerformed

    private void RemoveButton10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RemoveButton10ActionPerformed
        // get the selected Activity
        int index = ActivityList10.getSelectedIndex();

        // if there is no Activity Selected the index -1
        if (index == -1) {
            JOptionPane.showMessageDialog(this, "You did not select any Activity to remove",
                    "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            //remove the activity from the vector w/ the index

            Activity10.remove(index);

            // set the Activity vector as the List data of the namesList
            ActivityList10.setListData(Activity10);
            timer10.start();
        }
    }//GEN-LAST:event_RemoveButton10ActionPerformed

    private void jComboBox1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox1ActionPerformed
        int Logout = jComboBox1.getSelectedIndex();

        Login l = new Login();
        JOptionPane.showMessageDialog(this, "Welcome to ACtiTRACKER");
        l.setVisible(true);
        l.pack();
        l.setLocationRelativeTo(null);
        l.setDefaultCloseOperation(Login.EXIT_ON_CLOSE);
        this.dispose();
    }//GEN-LAST:event_jComboBox1ActionPerformed

    private void t2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_t2ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        t1.setText(jLabel9.getText());
        t2.setText(jLabel9.getText());
        t3.setText(jLabel9.getText());
        t4.setText(jLabel9.getText());
        t5.setText(jLabel9.getText());
        t6.setText(jLabel9.getText());
        t7.setText(jLabel9.getText());
        t8.setText(jLabel9.getText());
        t9.setText(jLabel9.getText());
        t10.setText(jLabel9.getText());
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed


        if (evt.getActionCommand() == "Set Alarm"){

            JOptionPane.showMessageDialog(null, "Alarm has been set");

            SetAlarm();


        }//end of if

    }//GEN-LAST:event_jButton1ActionPerformed

    private void t1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_t1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) throws Exception {

        java.awt.EventQueue.invokeLater(new Runnable() {

            public void run() {
                new MainScreen().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JList<String> ActivityList1;
    private javax.swing.JList<String> ActivityList10;
    private javax.swing.JList<String> ActivityList2;
    private javax.swing.JList<String> ActivityList3;
    private javax.swing.JList<String> ActivityList4;
    private javax.swing.JList<String> ActivityList5;
    private javax.swing.JList<String> ActivityList6;
    private javax.swing.JList<String> ActivityList7;
    private javax.swing.JList<String> ActivityList8;
    private javax.swing.JList<String> ActivityList9;
    private javax.swing.JButton AddButton1;
    private javax.swing.JButton AddButton10;
    private javax.swing.JButton AddButton2;
    private javax.swing.JButton AddButton3;
    private javax.swing.JButton AddButton4;
    private javax.swing.JButton AddButton5;
    private javax.swing.JButton AddButton6;
    private javax.swing.JButton AddButton7;
    private javax.swing.JButton AddButton8;
    private javax.swing.JButton AddButton9;
    private javax.swing.JButton RemoveButton1;
    private javax.swing.JButton RemoveButton10;
    private javax.swing.JButton RemoveButton2;
    private javax.swing.JButton RemoveButton3;
    private javax.swing.JButton RemoveButton4;
    private javax.swing.JButton RemoveButton5;
    private javax.swing.JButton RemoveButton6;
    private javax.swing.JButton RemoveButton7;
    private javax.swing.JButton RemoveButton8;
    private javax.swing.JButton RemoveButton9;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel11;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JProgressBar jProgressBar1;
    private javax.swing.JProgressBar jProgressBar10;
    private javax.swing.JProgressBar jProgressBar2;
    private javax.swing.JProgressBar jProgressBar3;
    private javax.swing.JProgressBar jProgressBar4;
    private javax.swing.JProgressBar jProgressBar5;
    private javax.swing.JProgressBar jProgressBar6;
    private javax.swing.JProgressBar jProgressBar7;
    private javax.swing.JProgressBar jProgressBar8;
    private javax.swing.JProgressBar jProgressBar9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane10;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JScrollPane jScrollPane7;
    private javax.swing.JScrollPane jScrollPane8;
    private javax.swing.JScrollPane jScrollPane9;
    private keeptoo.KGradientPanel kGradientPanel1;
    private keeptoo.KGradientPanel kGradientPanel2;
    private keeptoo.KGradientPanel kGradientPanel4;
    private javax.swing.JTextField t1;
    private javax.swing.JTextField t10;
    private javax.swing.JTextField t2;
    private javax.swing.JTextField t3;
    private javax.swing.JTextField t4;
    private javax.swing.JTextField t5;
    private javax.swing.JTextField t6;
    private javax.swing.JTextField t7;
    private javax.swing.JTextField t8;
    private javax.swing.JTextField t9;
    // End of variables declaration//GEN-END:variables

}
